package com.example.acer.mymoviesapplication.FavoriteMovies;

import android.annotation.SuppressLint;
import android.app.Application;
import android.arch.lifecycle.LiveData;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.util.Log;

import java.util.List;

import static android.content.ContentValues.TAG;

public class DataRepository {


    private MoviesDao myDAO;
    private LiveData<List<FavModel>> rgetdata;

    public DataRepository( @NonNull Application application) {
        DataBase myDatabase=DataBase.getdbasedata(application);
        myDAO=myDatabase.mydatabaseDao();
        rgetdata = myDAO.getdata();
    }

    public FavModel checkfav(int id) {
        Log.d(TAG, "checkfav: ");
       FavModel favModel=myDAO.checkfav(id);
        return favModel;
    }

    public LiveData<List<FavModel>> getdata() {

        return rgetdata;
    }

    public void insertinto(FavModel favouriteMovies) {
        new insertAsync(myDAO).execute(favouriteMovies);

    }

    private class insertAsync extends AsyncTask<FavModel, Void, Void> {
        private MoviesDao myasyncdao;
        insertAsync(MoviesDao myDao) {
            myasyncdao = myDao;
        }

        @Override
        protected Void doInBackground(FavModel... favModels) {
            myasyncdao.insertinto(favModels[0]);

            return null;
        }
    }

        public void deleteinto(FavModel favouriteMovies) {

            new deleteAsync(myDAO).execute(favouriteMovies);


        }

        private class deleteAsync extends AsyncTask<FavModel,Void,Void>{
            private MoviesDao myasyncdao2;
            deleteAsync(MoviesDao myDao2) {

                myasyncdao2=myDao2;
            }



            @Override
            protected Void doInBackground(FavModel... favModels) {
                myasyncdao2.deleteinto(favModels[0]);

                return null;
            }
        }


    }

