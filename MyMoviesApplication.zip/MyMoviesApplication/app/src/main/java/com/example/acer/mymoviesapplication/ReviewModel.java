package com.example.acer.mymoviesapplication;

public class ReviewModel {

    String rauthour;
    String rcontent;
    public ReviewModel(String rrauthor, String rcontent) {

        this.rauthour=rrauthor;
        this.rcontent=rcontent;
    }

    public String getRauthour() {
        return rauthour;
    }

    public void setRauthour(String rauthour) {
        this.rauthour = rauthour;
    }

    public String getRcontent() {
        return rcontent;
    }

    public void setRcontent(String rcontent) {
        this.rcontent = rcontent;
    }
}
