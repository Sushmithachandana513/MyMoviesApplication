package com.example.acer.mymoviesapplication;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProviders;
import android.arch.persistence.room.Room;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.acer.mymoviesapplication.FavoriteMovies.DataBase;
import com.example.acer.mymoviesapplication.FavoriteMovies.DataRepository;
import com.example.acer.mymoviesapplication.FavoriteMovies.FavModel;
import com.example.acer.mymoviesapplication.FavoriteMovies.FavMovies;
import com.github.ivbaranov.mfb.MaterialFavoriteButton;
import com.squareup.picasso.Picasso;

import java.util.List;

public class DetailActivity extends AppCompatActivity {

    ImageView image;
    TextView mtitle, moriginal, mId, mrelease, mrate, moverview;
    String id;
    String titles;
    String vote_average;
    String posterpath;
    String orgitle;
    String overview;
    String reldate;
    DataBase myDatabase;
    FavMovies favViewModel;
    MaterialFavoriteButton favorite;
    DataRepository dataRepository;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        image = findViewById(R.id.imageView1);
        mtitle = findViewById(R.id.tv1);
        moriginal = findViewById(R.id.tv2);
        mId = findViewById(R.id.tv3);
        mrelease = findViewById(R.id.tv4);
        mrate = findViewById(R.id.tv5);
        moverview = findViewById(R.id.tv6);
        favViewModel= ViewModelProviders.of(this).get(FavMovies.class);


        Picasso.with(this).load(getIntent().getStringExtra("poster")).into(image);
        favViewModel= ViewModelProviders.of(this).get(FavMovies.class);
        mtitle.setText(getIntent().getStringExtra("title"));
        mId.setText(getIntent().getStringExtra("id"));
        moriginal.setText(getIntent().getStringExtra("original"));
        mrelease.setText(getIntent().getStringExtra("release"));
        mrate.setText(getIntent().getStringExtra("rating"));
        moverview.setText(getIntent().getStringExtra("overview"));

        dataRepository=new DataRepository(getApplication());


        favorite=findViewById(R.id.favButton);

        posterpath=getIntent().getStringExtra("poster");
        orgitle=getIntent().getStringExtra("original");
        titles=getIntent().getStringExtra("title");
        reldate=getIntent().getStringExtra("release");
        vote_average=getIntent().getStringExtra("rating");
        overview=getIntent().getStringExtra("overview");
        id = getIntent().getStringExtra("id");


        myDatabase= Room.databaseBuilder(this,DataBase.class,"movies_db")
                .fallbackToDestructiveMigration().allowMainThreadQueries().build();
        //Toast.makeText(this, ""+id, Toast.LENGTH_SHORT).show();
        savedatafav();

        favorite.setOnFavoriteChangeListener(new MaterialFavoriteButton.OnFavoriteChangeListener() {
            @Override
            public void onFavoriteChanged(MaterialFavoriteButton buttonView, boolean favorite) {
                if (favorite){

                    Toast.makeText(DetailActivity.this, "selected", Toast.LENGTH_SHORT).show();

                    FavModel favouriteMovies=new FavModel();
                    favouriteMovies.setFid(Integer.valueOf(id));
                    favouriteMovies.setReldate(reldate);
                    favouriteMovies.setPosterpath(posterpath);
                    favouriteMovies.setOrgtitle(orgitle);
                    favouriteMovies.setOverview(overview);
                    favouriteMovies.setVoteaverage(vote_average);
                    favViewModel.insert(favouriteMovies);

                    Toast.makeText(DetailActivity.this, "Added to favourites", Toast.LENGTH_SHORT).show();
                }
                else{
                    FavModel favouriteMovies=new FavModel();
                    favouriteMovies.setFid(Integer.parseInt(id));
                    favouriteMovies.setReldate(reldate);
                    favouriteMovies.setPosterpath(posterpath);
                    favouriteMovies.setOrgtitle(orgitle);
                    favouriteMovies.setOverview(overview);
                    favouriteMovies.setVoteaverage(vote_average);
                    favViewModel.delete(favouriteMovies);
                    Toast.makeText(DetailActivity.this, "Removed from favourites", Toast.LENGTH_SHORT).show();
                }

            }
        });


        if(getSupportActionBar()!=null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }


    }

    public void savedatafav(){
        //Toast.makeText(this, ""+id, Toast.LENGTH_SHORT).show();
        FavModel favourite=dataRepository.checkfav(Integer.valueOf(id));
        if (favourite!=null){
            favorite.setFavorite(true);
        }
        else {
            favorite.setFavorite(false);
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }



    public void trailer(View view) {

        Intent intent=new Intent(DetailActivity.this,TrailersActivity.class);
        intent.putExtra("id",id);
        startActivity(intent);
    }

    public void reviews(View view) {

        Intent intent=new Intent(DetailActivity.this,ReviewsActivity.class);
        intent.putExtra("id",id);
        startActivity(intent);
    }
}
