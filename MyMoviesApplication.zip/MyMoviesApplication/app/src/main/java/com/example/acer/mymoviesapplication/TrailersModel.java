package com.example.acer.mymoviesapplication;

public class TrailersModel {

    String trailerkey;
    String trailername;
    String trailertype;

    public TrailersModel(String key, String names, String types) {
        this.trailerkey=key;
        this.trailername=names;
        this.trailertype=types;
        }

    public String getTrailerkey() {
        return trailerkey;
    }

    public void setTrailerkey(String trailerkey) {
        this.trailerkey = trailerkey;
    }

    public String getTrailername() {
        return trailername;
    }

    public void setTrailername(String trailername) {
        this.trailername = trailername;
    }

    public String getTrailertype() {
        return trailertype;
    }

    public void setTrailertype(String trailertype) {
        this.trailertype = trailertype;
    }


}
