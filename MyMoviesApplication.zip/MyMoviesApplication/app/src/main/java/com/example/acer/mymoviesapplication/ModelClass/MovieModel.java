package com.example.acer.mymoviesapplication.ModelClass;

import android.os.Parcel;
import android.os.Parcelable;

public class MovieModel implements Parcelable {

    String movieposter, movietitle, mid, movieoriginal, moviereleasedate, movierating, movieoverview;

    public MovieModel(String poster, String title, String originalTitle, String id, String releasedate, String vote, String overview) {

        movieposter = poster;
        movietitle = title;
        movierating = vote;
        mid = id;
        moviereleasedate = releasedate;
        movieoriginal = originalTitle;
        movieoverview = overview;


    }


    protected MovieModel(Parcel in) {
        movieposter = in.readString();
        movietitle = in.readString();
        mid = in.readString();
        movieoriginal = in.readString();
        moviereleasedate = in.readString();
        movierating = in.readString();
        movieoverview = in.readString();
    }

    public static final Creator<MovieModel> CREATOR = new Creator<MovieModel>() {
        @Override
        public MovieModel createFromParcel(Parcel in) {
            return new MovieModel(in);
        }

        @Override
        public MovieModel[] newArray(int size) {
            return new MovieModel[size];
        }
    };

    public String getMovieposter() {
        return movieposter;
    }

    public void setMovieposter(String movieposter) {
        this.movieposter = movieposter;
    }

    public String getMovietitle() {
        return movietitle;
    }

    public void setMovietitle(String movietitle) {
        this.movietitle = movietitle;
    }

    public String getMid() {
        return mid;
    }

    public void setMid(String mid) {
        this.mid = mid;
    }

    public String getMovieoriginal() {
        return movieoriginal;
    }

    public void setMovieoriginal(String movieoriginal) {
        this.movieoriginal = movieoriginal;
    }

    public String getMoviereleasedate() {
        return moviereleasedate;
    }

    public void setMoviereleasedate(String moviereleasedate) {
        this.moviereleasedate = moviereleasedate;
    }

    public String getMovieoverview() {
        return movieoverview;
    }

    public void setMovieoverview(String movieoverview) {
        this.movieoverview = movieoverview;
    }

    public String getMovierating() {
        return movierating;
    }

    public void setMovierating(String movierating) {
        this.movierating = movierating;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(movieposter);
        dest.writeString(movietitle);
        dest.writeString(mid);
        dest.writeString(movieoriginal);
        dest.writeString(moviereleasedate);
        dest.writeString(movierating);
        dest.writeString(movieoverview);
    }
}
