package com.example.acer.mymoviesapplication;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class TrailersActivity extends AppCompatActivity {

    RecyclerView rv;
    ArrayList<TrailersModel> trailersArrayList;
    String id;
    InputStream inputStream;
    BufferedReader bufferedReader;
    StringBuilder stringBuilder;
    String key,names,types;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trailers);
        rv=findViewById(R.id.rectrailers);

        id=getIntent().getStringExtra("id");

        trailersArrayList=new ArrayList<>();
        TrailerLoad trailersTask=new TrailerLoad();
        getSupportLoaderManager().initLoader(Integer.valueOf(id),null,trailersTask);

        if(getSupportActionBar()!=null){
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId()==android.R.id.home){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    public class TrailerLoad implements LoaderManager.LoaderCallbacks<String>

    {

        @NonNull
        @Override
        public Loader<String> onCreateLoader(final int id, @Nullable Bundle args) {
            return new AsyncTaskLoader<String>(TrailersActivity.this) {
                @Override
                protected void onStartLoading() {
                    super.onStartLoading();
                    forceLoad();
                }


                @Nullable
                @Override
                public String loadInBackground() {
                    String UrlLink="https://api.themoviedb.org/3/movie/"+id+"/videos?api_key=3ca91702fd993d9b6701dc56afd8ccd8";
                    try {
                        URL url=new URL(UrlLink);
                        HttpURLConnection httpURLConnection= (HttpURLConnection) url.openConnection();
                        httpURLConnection.setRequestMethod("GET");
                        httpURLConnection.connect();
                        inputStream=httpURLConnection.getInputStream();
                        bufferedReader=new BufferedReader(new InputStreamReader(inputStream));
                        stringBuilder=new StringBuilder();
                        String strline="";
                        while ((strline=bufferedReader.readLine())!=null){
                            stringBuilder.append(strline);
                        }
                        return stringBuilder.toString();
                    }  catch (Exception e) {
                        e.printStackTrace();
                    }
                    return null;
                }

            };
        }



        @Override
        public void onLoadFinished(@NonNull Loader<String> loader, String data) {

            trailersArrayList=new ArrayList<>();
            try {
                JSONObject nroot=new JSONObject(data);
                JSONArray narrray=nroot.getJSONArray("results");
                for(int i=0;i<narrray.length();i++){
                    JSONObject jsonObject=narrray.getJSONObject(i);
                    key=jsonObject.getString("key");
                    names=jsonObject.getString("name");
                    types=jsonObject.getString("type");
                    TrailersModel trailers=new TrailersModel(key,names,types);
                    trailersArrayList.add(trailers);
                }
                TrailersAdapter trailersAdapt=new TrailersAdapter(TrailersActivity.this,trailersArrayList);
                rv.setAdapter(trailersAdapt);
                rv.setLayoutManager(new LinearLayoutManager(TrailersActivity.this));

            } catch (JSONException e) {
                e.printStackTrace();
            }


        }

        @Override
        public void onLoaderReset(@NonNull Loader<String> loader) {

        }
    }
}
