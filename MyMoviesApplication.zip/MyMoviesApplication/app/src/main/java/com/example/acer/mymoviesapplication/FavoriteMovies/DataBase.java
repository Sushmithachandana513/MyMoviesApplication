package com.example.acer.mymoviesapplication.FavoriteMovies;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.content.Context;

@Database(entities = {FavModel.class},version = 5,exportSchema = false)

public abstract class DataBase extends RoomDatabase {

    public abstract MoviesDao mydatabaseDao();

    private static volatile DataBase INSTANCE;

    static DataBase getdbasedata(final Context cnt){
        if (INSTANCE==null){
            INSTANCE= Room.databaseBuilder(cnt.getApplicationContext(),
                    DataBase.class,"my_database")
                    .fallbackToDestructiveMigration()
                    .allowMainThreadQueries()
                    .build();
        }
        return INSTANCE;
    }


}
