package com.example.acer.mymoviesapplication.FavoriteMovies;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

@Entity(tableName = "Favourite_Movies")
public class FavModel {

    @PrimaryKey
    public int fid;

    public String ftitle;
    public String voteaverage;
    public String orgtitle;
    public String posterpath;
    public String overview;
    public String reldate;

    public FavModel() {

    }


    public String getFtitle() {
        return ftitle;
    }

    public void setFtitle(String ftitle) {
        this.ftitle = ftitle;
    }

    public FavModel(@NonNull String posterpath, String ftitle, int fid, String orgtitle, String reldate, String voteaverage, String overview) {
        this.fid = fid;
        this.voteaverage = voteaverage;
        this.orgtitle = orgtitle;
        this.posterpath = posterpath;
        this.overview = overview;
        this.reldate = reldate;
        this.ftitle=ftitle;


    }

    @NonNull
    public int getFid() {
        return fid;
    }

    public void setFid(@NonNull int fid) {
        this.fid = fid;
    }

    public String getVoteaverage() {
        return voteaverage;
    }

    public void setVoteaverage(String voteaverage) {
        this.voteaverage = voteaverage;
    }

    public String getOrgtitle() {
        return orgtitle;
    }

    public void setOrgtitle(String orgtitle) {
        this.orgtitle = orgtitle;
    }

    public String getPosterpath() {
        return posterpath;
    }

    public void setPosterpath(String posterpath) {
        this.posterpath = posterpath;
    }

    public String getOverview() {
        return overview;
    }

    public void setOverview(String overview) {
        this.overview = overview;
    }

    public String getReldate() {
        return reldate;
    }

    public void setReldate(String reldate) {
        this.reldate = reldate;
    }


}
