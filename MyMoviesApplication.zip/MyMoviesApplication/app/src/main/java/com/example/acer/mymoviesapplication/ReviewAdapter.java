package com.example.acer.mymoviesapplication;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class ReviewAdapter extends RecyclerView.Adapter<ReviewAdapter.HolderReview> {

    Context context;
    ArrayList<ReviewModel> reviewsArrayList;
    public ReviewAdapter(ReviewsActivity reviewsActivity, ArrayList<ReviewModel> reviewsArrayList) {

        this.context=reviewsActivity;
        this.reviewsArrayList=reviewsArrayList;
    }

    @NonNull
    @Override
    public HolderReview onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(context).inflate(R.layout.itemreviews,parent,false);
        return new HolderReview(view);    }

    @Override
    public void onBindViewHolder(@NonNull ReviewAdapter.HolderReview holder, int position) {
        holder.authortextView.setText(reviewsArrayList.get(position).getRauthour());
        holder.contenttextview.setText(reviewsArrayList.get(position).getRcontent());

    }



    @Override
    public int getItemCount() {
        return reviewsArrayList.size();
    }

    public class HolderReview extends RecyclerView.ViewHolder {

        TextView authortextView;
        TextView contenttextview;


        public HolderReview(View itemView)  {
            super(itemView);

            authortextView=itemView.findViewById(R.id.authoridtext);
            contenttextview=itemView.findViewById(R.id.contentid);
        }
    }
}
