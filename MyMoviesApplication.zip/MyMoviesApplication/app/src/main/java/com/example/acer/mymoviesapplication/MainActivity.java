package com.example.acer.mymoviesapplication;

import android.app.AlertDialog;
import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.Loader;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.example.acer.mymoviesapplication.Adapters.MovieAdapter;
import com.example.acer.mymoviesapplication.FavoriteMovies.DataBase;
import com.example.acer.mymoviesapplication.FavoriteMovies.FavModel;
import com.example.acer.mymoviesapplication.FavoriteMovies.FavMovies;
import com.example.acer.mymoviesapplication.FavoriteMovies.FavouriteAdapter;
import com.example.acer.mymoviesapplication.ModelClass.MovieModel;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements LoaderManager.LoaderCallbacks<String> {

    StatefulRecyclerView recycler;
    ArrayList<MovieModel> arrayList;
    String imagelink = "https://image.tmdb.org/t/p/w500";
    MovieAdapter adapter;
    Bundle bun;

    SharedPreferences preferences;
    SharedPreferences.Editor editor;


    FavMovies favViewModel1;
    List<FavModel> favouriteMoviesList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recycler = findViewById(R.id.recyclerView);
        recycler.setLayoutManager(new GridLayoutManager(this, 2));
        favouriteMoviesList = new ArrayList<>();
        favViewModel1 = ViewModelProviders.of(this).get(FavMovies.class);
        preferences = getPreferences(MODE_PRIVATE);
        String valuenew = preferences.getString("key", "null");

        if (savedInstanceState != null) {
            getSupportLoaderManager().destroyLoader(1);
            arrayList = savedInstanceState.getParcelableArrayList("list");
            adapter = new MovieAdapter(this, arrayList);
            recycler.setAdapter(adapter);
            recycler.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));

        } else {

            if (valuenew.equalsIgnoreCase("null")) {
                checknetwork();
            } else {
                if (valuenew.equalsIgnoreCase("pmovie")) {
                    popularmovie();
                } else if (valuenew.equalsIgnoreCase("hmovie")) {
                    highratedMovies();
                } else if (valuenew.equalsIgnoreCase("fmovie")) {
                    displayFvrt();
                } else {
                    checknetwork();
                }


                if (getApplicationContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                    recycler.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));
                } else {
                    recycler.setLayoutManager(new GridLayoutManager(MainActivity.this, 4));
                }
            }
        }
    }


    public void checknetwork() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if ((networkInfo != null) && (networkInfo.isConnected())) {
            bun = new Bundle();
            bun.putString("mypop", "popular");
            getSupportLoaderManager().initLoader(1, bun, this);
        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Check your Network Connection....");
            builder.setTitle("No Network...");
            builder.setCancelable(false);
            builder.setPositiveButton("Close App", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    finish();
                }
            });
            builder.show();
        }
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menus, menu);
        return super.onCreateOptionsMenu(menu);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.pop:
                getSupportLoaderManager().destroyLoader(1);
                editor = preferences.edit();
                editor.putString("key", "pmovie");
                editor.apply();
                popularmovie();
                break;
            case R.id.top:
                getSupportLoaderManager().destroyLoader(1);
                editor = preferences.edit();
                editor.putString("key", "hmovie");
                editor.apply();
                highratedMovies();
                break;
            case R.id.fav:
                editor = preferences.edit();
                editor.putString("key", "fmovie");
                editor.apply();
                displayFvrt();
                break;

            default:
                break;


        }
        return super.onOptionsItemSelected(item);
    }

    private void displayFvrt() {
        favViewModel1.getdata().observe(this, new Observer<List<FavModel>>() {
            @Override
            public void onChanged(@Nullable List<FavModel> favouriteMovies) {
                favouriteMoviesList = favouriteMovies;
                if (favouriteMoviesList.size() == 0) {
                    Toast.makeText(MainActivity.this, "No Favourites", Toast.LENGTH_SHORT).show();
                } else {
                    FavouriteAdapter favAdapt = new FavouriteAdapter(MainActivity.this, favouriteMoviesList);
                    recycler.setAdapter(favAdapt);
                    if (getApplicationContext().getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
                        recycler.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));
                    } else {
                        recycler.setLayoutManager(new GridLayoutManager(MainActivity.this, 4));
                    }


                }

            }
        });
    }

    private void popularmovie() {
        Bundle bundle1 = new Bundle();
        bundle1.putString("mypop", "popular");
        getSupportLoaderManager().initLoader(1, bundle1, this);
    }


    private void highratedMovies() {
        Bundle bundle2 = new Bundle();
        bundle2.putString("mypop", "top_rated");
        getSupportLoaderManager().initLoader(1, bundle2, this);
    }


    @NonNull
    @Override
    public Loader<String> onCreateLoader(int id, @Nullable Bundle args) {

        return new LoadersPopular(this, args);
    }

    @Override
    public void onLoadFinished(@NonNull Loader<String> loader, String data) {
        arrayList = new ArrayList<MovieModel>();


        try {
            JSONObject object = new JSONObject(data);
            JSONArray jsonArray = object.getJSONArray("results");
            for (int i = 0; i < jsonArray.length(); i++) {

                JSONObject object1 = jsonArray.getJSONObject(i);
                String poster = imagelink + object1.getString("poster_path");
                String title = object1.getString("title");
                String originalTitle = object1.getString("original_title");
                String id = object1.getString("id");
                String releasedate = object1.getString("release_date");
                String overview = object1.getString("overview");
                String vote = object1.getString("vote_average");


                MovieModel movieModel = new MovieModel(poster, title, originalTitle, id, releasedate, vote, overview);

                arrayList.add(movieModel);

            }

            adapter = new MovieAdapter(this, arrayList);

            recycler.setAdapter(adapter);
            recycler.setLayoutManager(new GridLayoutManager(MainActivity.this, 2));

        } catch (Exception e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onLoaderReset(@NonNull Loader<String> loader) {

    }


    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        outState.putParcelableArrayList("list", arrayList);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        getSupportLoaderManager().destroyLoader(1);
    }
}

