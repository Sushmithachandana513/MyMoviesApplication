package com.example.acer.mymoviesapplication.Adapters;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.acer.mymoviesapplication.DetailActivity;
import com.example.acer.mymoviesapplication.MainActivity;
import com.example.acer.mymoviesapplication.ModelClass.MovieModel;
import com.example.acer.mymoviesapplication.R;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.ViewHolder> {

    Context ct;
    ArrayList<MovieModel> list;

    public MovieAdapter(MainActivity mainActivity, ArrayList<MovieModel> arrayList) {
        ct = mainActivity;
        list = arrayList;
    }

    @NonNull
    @Override
    public MovieAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View vw = LayoutInflater.from(ct).inflate(R.layout.item, parent, false);
        return new MovieAdapter.ViewHolder(vw, ct, list);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieAdapter.ViewHolder holder, int position) {

        Picasso.with(ct).load(list.get(position).getMovieposter()).into(holder.imageView);

    }


    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {


        Context ctx;
        ArrayList<MovieModel> mylist;
        ImageView imageView;

        public ViewHolder(View itemView, Context ct, ArrayList<MovieModel> list) {
            super(itemView);
            itemView.setOnClickListener(this);
            ctx = ct;
            mylist = list;
            imageView = itemView.findViewById(R.id.image);
        }

        @Override
        public void onClick(View v) {

            int pos = getAdapterPosition();
            MovieModel movieModel = this.mylist.get(pos);
            Intent intent = new Intent(ctx, DetailActivity.class);
            intent.putExtra("poster", movieModel.getMovieposter());
            intent.putExtra("title", movieModel.getMovietitle());
            intent.putExtra("id", movieModel.getMid());
            intent.putExtra("original", movieModel.getMovieoriginal());
            intent.putExtra("release", movieModel.getMoviereleasedate());
            intent.putExtra("rating", movieModel.getMovierating());
            intent.putExtra("overview", movieModel.getMovieoverview());
            ctx.startActivity(intent);

        }
    }
}

