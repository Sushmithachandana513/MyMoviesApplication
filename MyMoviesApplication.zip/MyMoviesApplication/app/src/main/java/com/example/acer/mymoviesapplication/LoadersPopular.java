package com.example.acer.mymoviesapplication;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.content.AsyncTaskLoader;
import android.support.v4.content.Loader;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoadersPopular extends AsyncTaskLoader<String> {

    Bundle bundle;
    String moviekey;

    public LoadersPopular(Context context, Bundle args) {
        super(context);
        this.bundle = args;
    }


    @Override
    protected void onStartLoading() {
        super.onStartLoading();
        forceLoad();
    }

    @Nullable
    @Override
    public String loadInBackground() {

        moviekey = bundle.getString("mypop");

        String Url = "https://api.themoviedb.org/3/movie/" + moviekey+ "?api_key=0e69ff8cac22ff8bce9b7b7e6da2d296";

        Uri buildUri = Uri.parse(Url);
        try {
            URL url = new URL(buildUri.toString());
            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.connect();

            InputStream inputStream = httpURLConnection.getInputStream();
            StringBuffer buffer = new StringBuffer();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                buffer.append(line + "\n");

            }
            return buffer.toString();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
