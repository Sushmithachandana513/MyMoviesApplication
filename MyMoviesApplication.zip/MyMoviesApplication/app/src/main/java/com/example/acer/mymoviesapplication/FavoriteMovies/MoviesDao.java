package com.example.acer.mymoviesapplication.FavoriteMovies;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;

import java.util.List;

@Dao

public interface MoviesDao {

    @Query("SELECT * FROM Favourite_Movies")
    LiveData<List<FavModel>> getdata();


    @Query("SELECT * FROM Favourite_Movies WHERE fid = :id")
    FavModel checkfav(int id);

    @Insert
    void insertinto(FavModel favouriteMovies);

    @Delete
    void deleteinto(FavModel favouriteMovies);




}
