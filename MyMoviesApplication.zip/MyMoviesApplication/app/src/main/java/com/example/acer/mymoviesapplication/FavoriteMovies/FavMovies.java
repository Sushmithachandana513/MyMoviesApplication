package com.example.acer.mymoviesapplication.FavoriteMovies;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.LiveData;
import android.support.annotation.NonNull;

import java.util.List;

public class FavMovies extends AndroidViewModel {

    private DataRepository dataRepository;
    private LiveData<List<FavModel>> mgetdata;

    public FavMovies(@NonNull Application application) {
        super(application);
        dataRepository=new DataRepository(application);
        mgetdata=dataRepository.getdata();
    }

    public FavModel checkfav(int id){
        FavModel favouriteMovies=dataRepository.checkfav(id);
        return favouriteMovies;
    }


    public LiveData<List<FavModel>>getdata()
    {

        return mgetdata;
    }

    public void insert(FavModel favouriteMovies){

        dataRepository.insertinto(favouriteMovies);
    }

    public void delete(FavModel favouriteMovies)
    {
        dataRepository.deleteinto(favouriteMovies);
    }

}
